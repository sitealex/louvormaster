class DB {
    constructor(name, version) {
        this.name = name;
        this.version = version;
        this.db = null;
    }
    
    async open() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(this.name, this.version);
            
            request.onerror = (event) => {
                console.error('Database error:', event.target.error);
                reject(event.target.error);
            };
            
            request.onsuccess = (event) => {
                this.db = event.target.result;
                resolve(this);
            };
            
            request.onupgradeneeded = (event) => {
                const db = event.target.result;
                
                // Cria a store de músicas
                if (!db.objectStoreNames.contains('musicas')) {
                    const musicasStore = db.createObjectStore('musicas', { keyPath: 'id' });
                    musicasStore.createIndex('titulo', 'titulo', { unique: false });
                    musicasStore.createIndex('artista', 'artista', { unique: false });
                }
                
                // Cria a store de membros
                if (!db.objectStoreNames.contains('membros')) {
                    const membrosStore = db.createObjectStore('membros', { keyPath: 'id' });
                    membrosStore.createIndex('nome', 'nome', { unique: false });
                    membrosStore.createIndex('funcao', 'funcao', { unique: false });
                }
                
                // Cria a store de escalas
                if (!db.objectStoreNames.contains('escalas')) {
                    db.createObjectStore('escalas', { keyPath: 'id' });
                }
                
                // Cria a store de eventos
                if (!db.objectStoreNames.contains('eventos')) {
                    db.createObjectStore('eventos', { keyPath: 'id' });
                }
                
                // Cria a store de mensagens
                if (!db.objectStoreNames.contains('mensagens')) {
                    db.createObjectStore('mensagens', { keyPath: 'id' });
                }
                
                // Cria a store de configurações
                if (!db.objectStoreNames.contains('config')) {
                    db.createObjectStore('config', { keyPath: 'id' });
                }
            };
        });
    }
    
    async add(storeName, data) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([storeName], 'readwrite');
            const store = transaction.objectStore(storeName);
            
            // Gera um ID único se não existir
            if (!data.id) {
                data.id = Date.now().toString() + Math.random().toString(36).substr(2, 9);
            }
            
            const request = store.add(data);
            
            request.onsuccess = () => resolve(data.id);
            request.onerror = (event) => reject(event.target.error);
        });
    }
    
    async get(storeName, id) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([storeName], 'readonly');
            const store = transaction.objectStore(storeName);
            
            const request = store.get(id);
            
            request.onsuccess = () => resolve(request.result);
            request.onerror = (event) => reject(event.target.error);
        });
    }
    
    async getAll(storeName, indexName, query) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([storeName], 'readonly');
            const store = transaction.objectStore(storeName);
            
            let request;
            if (indexName) {
                const index = store.index(indexName);
                request = index.getAll(query);
            } else {
                request = store.getAll();
            }
            
            request.onsuccess = () => resolve(request.result);
            request.onerror = (event) => reject(event.target.error);
        });
    }
    
    async update(storeName, data) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([storeName], 'readwrite');
            const store = transaction.objectStore(storeName);
            
            const request = store.put(data);
            
            request.onsuccess = () => resolve(data.id);
            request.onerror = (event) => reject(event.target.error);
        });
    }
    
    async delete(storeName, id) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([storeName], 'readwrite');
            const store = transaction.objectStore(storeName);
            
            const request = store.delete(id);
            
            request.onsuccess = () => resolve();
            request.onerror = (event) => reject(event.target.error);
        });
    }
    
    async count(storeName) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([storeName], 'readonly');
            const store = transaction.objectStore(storeName);
            
            const request = store.count();
            
            request.onsuccess = () => resolve(request.result);
            request.onerror = (event) => reject(event.target.error);
        });
    }
    
    async export() {
        const stores = Array.from(this.db.objectStoreNames);
        const data = {};
        
        for (const storeName of stores) {
            data[storeName] = await this.getAll(storeName);
        }
        
        return data;
    }
    
    async import(data) {
        const transaction = this.db.transaction(Array.from(this.db.objectStoreNames), 'readwrite');
        
        // Limpa todas as stores primeiro
        for (const storeName of transaction.objectStoreNames) {
            const store = transaction.objectStore(storeName);
            store.clear();
        }
        
        // Importa os dados
        for (const storeName in data) {
            if (this.db.objectStoreNames.contains(storeName)) {
                const store = transaction.objectStore(storeName);
                
                for (const item of data[storeName]) {
                    store.add(item);
                }
            }
        }
        
        return new Promise((resolve, reject) => {
            transaction.oncomplete = () => resolve();
            transaction.onerror = (event) => reject(event.target.error);
        });
    }
}

let dbInstance = null;

async function initDB() {
    if (!dbInstance) {
        dbInstance = new DB('LouvorMasterDB', 1);
        await dbInstance.open();
    }
    return dbInstance;
}

async function getDB() {
    if (!dbInstance) {
        await initDB();
    }
    return dbInstance;
}

export { initDB, getDB };