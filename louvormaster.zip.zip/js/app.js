document.addEventListener('DOMContentLoaded', function() {
    // Inicializa o banco de dados
    initDB().then(() => {
        loadDashboardData();
        setupEventListeners();
        checkOnlineStatus();
        
        // Verifica atualizações a cada 5 minutos
        setInterval(checkForUpdates, 300000);
    });
    
    // Configura o Service Worker para PWA
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register('sw.js').then(registration => {
            console.log('ServiceWorker registration successful');
        }).catch(err => {
            console.log('ServiceWorker registration failed: ', err);
        });
    }
});

function setupEventListeners() {
    // Navegação entre abas
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const tabId = this.id.replace('-tab', '');
            showTab(tabId);
        });
    });
    
    // Botão de sincronização
    document.getElementById('sync-button').addEventListener('click', syncData);
    
    // Repertório
    document.getElementById('add-musica-btn').addEventListener('click', showAddMusicaModal);
    document.getElementById('save-musica-btn').addEventListener('click', saveMusica);
    document.getElementById('search-btn').addEventListener('click', searchMusicas);
    document.getElementById('youtube-search-btn').addEventListener('click', searchYouTube);
    document.getElementById('search-musica').addEventListener('keyup', function(e) {
        if (e.key === 'Enter') searchMusicas();
    });
    document.getElementById('youtube-search').addEventListener('keyup', function(e) {
        if (e.key === 'Enter') searchYouTube();
    });
    
    // Escalas
    document.getElementById('add-escala-btn').addEventListener('click', showAddEscalaModal);
    document.getElementById('save-escala-btn').addEventListener('click', saveEscala);
    document.getElementById('add-musica-escala').addEventListener('click', addMusicaToEscala);
    
    // Eventos
    document.getElementById('add-evento-btn').addEventListener('click', showAddEventoModal);
    document.getElementById('save-evento-btn').addEventListener('click', saveEvento);
    document.getElementById('add-musica-evento').addEventListener('click', addMusicaToEvento);
    
    // Membros
    document.getElementById('add-membro-btn').addEventListener('click', showAddMembroModal);
    document.getElementById('save-membro-btn').addEventListener('click', saveMembro);
    document.getElementById('membro-funcao').addEventListener('change', function() {
        document.getElementById('outra-funcao-container').style.display = 
            this.value === 'Outro' ? 'block' : 'none';
    });
    
    // Mensagens
    document.getElementById('add-mensagem-btn').addEventListener('click', showAddMensagemModal);
    document.getElementById('enviar-mensagem-btn').addEventListener('click', enviarMensagem);
    document.getElementById('testar-mensagem-btn').addEventListener('click', testarMensagem);
    document.getElementById('mensagem-modelo').addEventListener('change', updateMensagemModelo);
    
    // Configurações
    document.getElementById('salvar-config-geral').addEventListener('click', salvarConfigGeral);
    document.getElementById('backup-btn').addEventListener('click', criarBackup);
    document.getElementById('restore-file').addEventListener('change', function() {
        document.getElementById('restore-btn').disabled = !this.files.length;
    });
    document.getElementById('restore-btn').addEventListener('click', restaurarBackup);
    document.getElementById('limpar-dados-btn').addEventListener('click', limparDadosLocais);
}

function showTab(tabId) {
    // Esconde todas as abas
    document.querySelectorAll('.tab-pane').forEach(tab => {
        tab.classList.remove('show', 'active');
    });
    
    // Remove a classe active de todos os links
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
    });
    
    // Mostra a aba selecionada
    document.getElementById(tabId).classList.add('show', 'active');
    document.getElementById(`${tabId}-tab`).classList.add('active');
    
    // Carrega os dados específicos da aba
    switch(tabId) {
        case 'repertorio':
            loadRepertorio();
            break;
        case 'escalas':
            loadEscalas();
            break;
        case 'eventos':
            loadEventos();
            break;
        case 'membros':
            loadMembros();
            break;
        case 'mensagens':
            loadMensagens();
            break;
        case 'config':
            loadConfig();
            break;
    }
}

// Funções para carregar dados
function loadDashboardData() {
    // Carrega estatísticas
    getDB().then(db => {
        // Total de músicas
        db.count('musicas').then(count => {
            document.getElementById('total-musicas').textContent = count;
        });
        
        // Total de membros
        db.count('membros').then(count => {
            document.getElementById('total-membros').textContent = count;
        });
        
        // Próximo evento
        db.getAll('eventos').then(eventos => {
            const now = new Date();
            const proximos = eventos.filter(e => new Date(e.data) > now)
                                  .sort((a, b) => new Date(a.data) - new Date(b.data));
            
            if (proximos.length > 0) {
                const evento = proximos[0];
                const data = new Date(evento.data).toLocaleDateString();
                document.getElementById('proximo-evento').innerHTML = `
                    <strong>${evento.titulo}</strong><br>
                    ${data} às ${evento.hora}
                `;
            }
        });
        
        // Músicas mais tocadas
        db.getAll('musicas').then(musicas => {
            const maisTocadas = musicas.sort((a, b) => b.vezesTocada - a.vezesTocada)
                                      .slice(0, 5);
            
            const list = document.getElementById('mais-tocadas');
            list.innerHTML = '';
            
            maisTocadas.forEach(musica => {
                const item = document.createElement('li');
                item.className = 'list-group-item d-flex justify-content-between align-items-center';
                item.innerHTML = `
                    ${musica.titulo}
                    <span class="badge bg-primary rounded-pill">${musica.vezesTocada}</span>
                `;
                list.appendChild(item);
            });
        });
        
        // Aniversariantes do mês
        db.getAll('membros').then(membros => {
            const hoje = new Date();
            const mesAtual = hoje.getMonth() + 1;
            
            const aniversariantes = membros.filter(membro => {
                if (!membro.aniversario) return false;
                const dataNasc = new Date(membro.aniversario);
                return dataNasc.getMonth() + 1 === mesAtual;
            });
            
            const list = document.getElementById('aniversariantes');
            list.innerHTML = '';
            
            if (aniversariantes.length === 0) {
                list.innerHTML = '<li class="list-group-item">Nenhum aniversariante este mês</li>';
                return;
            }
            
            aniversariantes.forEach(membro => {
                const item = document.createElement('li');
                item.className = 'list-group-item d-flex justify-content-between align-items-center';
                
                const dataNasc = new Date(membro.aniversario);
                const dia = dataNasc.getDate();
                const idade = hoje.getFullYear() - dataNasc.getFullYear();
                
                item.innerHTML = `
                    <div>
                        <strong>${membro.nome}</strong><br>
                        <small>${dia}/${mesAtual} - ${idade} anos</small>
                    </div>
                    <span class="badge ${getFuncaoBadgeClass(membro.funcao)}">
                        ${membro.funcao}
                    </span>
                `;
                list.appendChild(item);
            });
        });
    });
}

function getFuncaoBadgeClass(funcao) {
    const classes = {
        'Vocalista': 'bg-danger',
        'Baterista': 'bg-warning text-dark',
        'Guitarrista': 'bg-success',
        'Baixista': 'bg-primary',
        'Tecladista': 'bg-info',
        'Violonista': 'bg-secondary',
        'Ministro': 'bg-dark',
        'Backing Vocal': 'bg-light text-dark',
        'Outro': 'bg-light text-dark'
    };
    
    return classes[funcao] || 'bg-light text-dark';
}

// Funções para o repertório
function loadRepertorio() {
    getDB().then(db => {
        db.getAll('musicas').then(musicas => {
            const table = document.getElementById('repertorio-table');
            table.innerHTML = '';
            
            if (musicas.length === 0) {
                table.innerHTML = '<tr><td colspan="6">Nenhuma música cadastrada</td></tr>';
                return;
            }
            
            musicas.forEach((musica, index) => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${index + 1}</td>
                    <td>${musica.titulo}</td>
                    <td>${musica.artista || '-'}</td>
                    <td>${musica.tonalidade || '-'}</td>
                    <td>${musica.vezesTocada || 0}</td>
                    <td>
                        <button class="btn btn-sm btn-outline-primary btn-action" data-id="${musica.id}" onclick="editMusica('${musica.id}')">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn btn-sm btn-outline-danger btn-action" data-id="${musica.id}" onclick="deleteMusica('${musica.id}')">
                            <i class="fas fa-trash"></i>
                        </button>
                    </td>
                `;
                table.appendChild(row);
            });
        });
    });
}

function showAddMusicaModal() {
    // Limpa o formulário
    document.getElementById('musica-form').reset();
    
    // Mostra o modal
    const modal = new bootstrap.Modal(document.getElementById('addMusicaModal'));
    modal.show();
}

function saveMusica() {
    const musica = {
        titulo: document.getElementById('musica-titulo').value,
        artista: document.getElementById('musica-artista').value,
        tonalidade: document.getElementById('musica-tonalidade').value,
        link: document.getElementById('musica-link').value,
        letra: document.getElementById('musica-letra').value,
        cifra: document.getElementById('musica-cifra').value,
        vezesTocada: 0,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
    };
    
    const musicaId = document.getElementById('musica-form').dataset.id;
    
    getDB().then(db => {
        if (musicaId) {
            // Atualizar música existente
            musica.id = musicaId;
            db.update('musicas', musica).then(() => {
                showToast('Música atualizada com sucesso!', 'success');
                loadRepertorio();
                bootstrap.Modal.getInstance(document.getElementById('addMusicaModal')).hide();
            });
        } else {
            // Adicionar nova música
            db.add('musicas', musica).then(() => {
                showToast('Música adicionada com sucesso!', 'success');
                loadRepertorio();
                loadDashboardData();
                bootstrap.Modal.getInstance(document.getElementById('addMusicaModal')).hide();
            });
        }
    });
}

function editMusica(id) {
    getDB().then(db => {
        db.get('musicas', id).then(musica => {
            // Preenche o formulário
            document.getElementById('musica-titulo').value = musica.titulo;
            document.getElementById('musica-artista').value = musica.artista || '';
            document.getElementById('musica-tonalidade').value = musica.tonalidade || 'C';
            document.getElementById('musica-link').value = musica.link || '';
            document.getElementById('musica-letra').value = musica.letra || '';
            document.getElementById('musica-cifra').value = musica.cifra || '';
            
            // Armazena o ID para atualização
            document.getElementById('musica-form').dataset.id = musica.id;
            
            // Mostra o modal
            const modal = new bootstrap.Modal(document.getElementById('addMusicaModal'));
            modal.show();
        });
    });
}

function deleteMusica(id) {
    if (confirm('Tem certeza que deseja excluir esta música?')) {
        getDB().then(db => {
            db.delete('musicas', id).then(() => {
                showToast('Música excluída com sucesso!', 'success');
                loadRepertorio();
                loadDashboardData();
            });
        });
    }
}

function searchMusicas() {
    const termo = document.getElementById('search-musica').value.toLowerCase();
    
    getDB().then(db => {
        db.getAll('musicas').then(musicas => {
            const resultados = termo ? 
                musicas.filter(m => 
                    m.titulo.toLowerCase().includes(termo) || 
                    (m.artista && m.artista.toLowerCase().includes(termo))
                ) : 
                musicas;
            
            const table = document.getElementById('repertorio-table');
            table.innerHTML = '';
            
            if (resultados.length === 0) {
                table.innerHTML = '<tr><td colspan="6">Nenhuma música encontrada</td></tr>';
                return;
            }
            
            resultados.forEach((musica, index) => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${index + 1}</td>
                    <td>${musica.titulo}</td>
                    <td>${musica.artista || '-'}</td>
                    <td>${musica.tonalidade || '-'}</td>
                    <td>${musica.vezesTocada || 0}</td>
                    <td>
                        <button class="btn btn-sm btn-outline-primary btn-action" data-id="${musica.id}" onclick="editMusica('${musica.id}')">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn btn-sm btn-outline-danger btn-action" data-id="${musica.id}" onclick="deleteMusica('${musica.id}')">
                            <i class="fas fa-trash"></i>
                        </button>
                    </td>
                `;
                table.appendChild(row);
            });
        });
    });
}

function searchYouTube() {
    const query = document.getElementById('youtube-search').value;
    
    if (!query) {
        showToast('Digite um termo para buscar no YouTube', 'warning');
        return;
    }
    
    // Aqui você implementaria a busca na API do YouTube
    // Como exemplo, vamos simular resultados
    const resultados = [
        {
            title: 'Música de Louvor - Artista Gospel',
            videoId: 'abc123',
            thumbnail: 'https://i.ytimg.com/vi/abc123/default.jpg'
        },
        {
            title: 'Adoração e Louvor - Banda Cristã',
            videoId: 'def456',
            thumbnail: 'https://i.ytimg.com/vi/def456/default.jpg'
        }
    ];
    
    const modalBody = document.getElementById('youtube-results');
    modalBody.innerHTML = '<div class="text-center my-3"><div class="spinner-border" role="status"><span class="visually-hidden">Carregando...</span></div></div>';
    
    // Simular delay de rede
    setTimeout(() => {
        if (resultados.length === 0) {
            modalBody.innerHTML = '<p>Nenhum resultado encontrado para sua busca.</p>';
            return;
        }
        
        modalBody.innerHTML = `
            <div class="row">
                ${resultados.map(video => `
                    <div class="col-md-6 mb-3">
                        <div class="card h-100">
                            <img src="${video.thumbnail}" class="card-img-top" alt="${video.title}">
                            <div class="card-body">
                                <h6 class="card-title">${video.title}</h6>
                            </div>
                            <div class="card-footer bg-transparent">
                                <button class="btn btn-sm btn-success" onclick="addFromYouTube('${video.videoId}', '${video.title.replace("'", "\\'")}')">
                                    <i class="fas fa-plus"></i> Adicionar
                                </button>
                            </div>
                        </div>
                    </div>
                `).join('')}
            </div>
        `;
    }, 1000);
    
    const modal = new bootstrap.Modal(document.getElementById('youtubeModal'));
    modal.show();
}

function addFromYouTube(videoId, title) {
    // Preenche o formulário com os dados do YouTube
    document.getElementById('musica-form').reset();
    document.getElementById('musica-titulo').value = title;
    document.getElementById('musica-link').value = `https://www.youtube.com/watch?v=${videoId}`;
    
    // Fecha o modal do YouTube e abre o de adicionar música
    bootstrap.Modal.getInstance(document.getElementById('youtubeModal')).hide();
    
    const modal = new bootstrap.Modal(document.getElementById('addMusicaModal'));
    modal.show();
}

// Funções para escalas
function loadEscalas() {
    getDB().then(db => {
        db.getAll('escalas').then(escalas => {
            const table = document.getElementById('escalas-table');
            table.innerHTML = '';
            
            if (escalas.length === 0) {
                table.innerHTML = '<tr><td colspan="6">Nenhuma escala cadastrada</td></tr>';
                return;
            }
            
            // Ordena por data mais próxima
            escalas.sort((a, b) => new Date(a.data) - new Date(b.data));
            
            escalas.forEach(escala => {
                const data = new Date(escala.data);
                const hoje = new Date();
                const status = data < hoje ? 'Realizada' : 'Agendada';
                
                const participantes = escala.participantes.map(p => p.nome.split(' ')[0]).join(', ');
                
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${escala.evento}</td>
                    <td>${data.toLocaleDateString()}</td>
                    <td>${escala.hora}</td>
                    <td>${participantes}</td>
                    <td><span class="badge ${status === 'Agendada' ? 'bg-success' : 'bg-secondary'}">${status}</span></td>
                    <td>
                        <button class="btn btn-sm btn-outline-primary btn-action" data-id="${escala.id}" onclick="viewEscala('${escala.id}')">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="btn btn-sm btn-outline-danger btn-action" data-id="${escala.id}" onclick="deleteEscala('${escala.id}')">
                            <i class="fas fa-trash"></i>
                        </button>
                    </td>
                `;
                table.appendChild(row);
            });
        });
    });
}

function showAddEscalaModal() {
    // Limpa o formulário
    document.getElementById('escala-form').reset();
    document.getElementById('musicas-escala').innerHTML = '';
    
    // Preenche a data padrão (próximo domingo)
    const hoje = new Date();
    const proximoDomingo = new Date(hoje);
    proximoDomingo.setDate(hoje.getDate() + (7 - hoje.getDay()) % 7);
    
    document.getElementById('escala-data').valueAsDate = proximoDomingo;
    
    // Carrega os membros disponíveis
    getDB().then(db => {
        db.getAll('membros').then(membros => {
            const container = document.getElementById('membros-disponiveis');
            container.innerHTML = '';
            
            membros.forEach(membro => {
                const div = document.createElement('div');
                div.className = 'form-check';
                div.innerHTML = `
                    <input class="form-check-input" type="checkbox" value="${membro.id}" id="membro-${membro.id}">
                    <label class="form-check-label" for="membro-${membro.id}">
                        ${membro.nome} <span class="badge ${getFuncaoBadgeClass(membro.funcao)}">${membro.funcao}</span>
                    </label>
                `;
                container.appendChild(div);
            });
        });
        
        // Carrega as músicas para o dropdown
        db.getAll('musicas').then(musicas => {
            const select = document.getElementById('select-musica');
            select.innerHTML = '<option selected>Selecione uma música...</option>';
            
            musicas.forEach(musica => {
                const option = document.createElement('option');
                option.value = musica.id;
                option.textContent = musica.titulo;
                select.appendChild(option);
            });
        });
    });
    
    // Mostra o modal
    const modal = new bootstrap.Modal(document.getElementById('addEscalaModal'));
    modal.show();
}

function addMusicaToEscala() {
    const select = document.getElementById('select-musica');
    const musicaId = select.value;
    
    if (!musicaId || musicaId === 'Selecione uma música...') {
        showToast('Selecione uma música válida', 'warning');
        return;
    }
    
    getDB().then(db => {
        db.get('musicas', musicaId).then(musica => {
            const lista = document.getElementById('musicas-escala');
            
            // Verifica se a música já foi adicionada
            if (document.querySelector(`#musicas-escala li[data-id="${musica.id}"]`)) {
                showToast('Esta música já foi adicionada', 'warning');
                return;
            }
            
            const item = document.createElement('li');
            item.className = 'list-group-item d-flex justify-content-between align-items-center';
            item.dataset.id = musica.id;
            item.innerHTML = `
                ${musica.titulo} (${musica.tonalidade || 'N/D'})
                <button class="btn btn-sm btn-outline-danger" onclick="this.parentElement.remove()">
                    <i class="fas fa-times"></i>
                </button>
            `;
            
            lista.appendChild(item);
            select.value = 'Selecione uma música...';
        });
    });
}

function saveEscala() {
    const evento = document.getElementById('escala-evento').value;
    const data = document.getElementById('escala-data').value;
    const hora = document.getElementById('escala-hora').value;
    const observacoes = document.getElementById('escala-observacoes').value;
    const cor = document.querySelector('input[name="escala-cor"]:checked').value;
    
    if (!evento || !data || !hora) {
        showToast('Preencha todos os campos obrigatórios', 'warning');
        return;
    }
    
    // Coleta os participantes selecionados
    const participantes = [];
    document.querySelectorAll('#membros-disponiveis input[type="checkbox"]:checked').forEach(checkbox => {
        participantes.push(checkbox.value);
    });
    
    if (participantes.length === 0) {
        showToast('Selecione pelo menos um participante', 'warning');
        return;
    }
    
    // Coleta as músicas selecionadas
    const musicas = [];
    document.querySelectorAll('#musicas-escala li').forEach(li => {
        musicas.push(li.dataset.id);
    });
    
    if (musicas.length === 0) {
        showToast('Adicione pelo menos uma música', 'warning');
        return;
    }
    
    // Obtém os detalhes completos dos participantes
    getDB().then(db => {
        db.getAll('membros').then(todosMembros => {
            const participantesCompletos = participantes.map(id => {
                return todosMembros.find(m => m.id === id);
            });
            
            // Obtém os detalhes completos das músicas
            db.getAll('musicas').then(todasMusicas => {
                const musicasCompletas = musicas.map(id => {
                    return todasMusicas.find(m => m.id === id);
                });
                
                const escala = {
                    evento,
                    data,
                    hora,
                    observacoes,
                    cor,
                    participantes: participantesCompletos,
                    musicas: musicasCompletas,
                    createdAt: new Date().toISOString(),
                    updatedAt: new Date().toISOString()
                };
                
                // Salva no banco de dados
                db.add('escalas', escala).then(() => {
                    showToast('Escala salva com sucesso!', 'success');
                    loadEscalas();
                    loadDashboardData();
                    bootstrap.Modal.getInstance(document.getElementById('addEscalaModal')).hide();
                });
            });
        });
    });
}

function viewEscala(id) {
    // Implementação para visualizar detalhes da escala
    console.log('Visualizar escala:', id);
}

function deleteEscala(id) {
    if (confirm('Tem certeza que deseja excluir esta escala?')) {
        getDB().then(db => {
            db.delete('escalas', id).then(() => {
                showToast('Escala excluída com sucesso!', 'success');
                loadEscalas();
                loadDashboardData();
            });
        });
    }
}

// Funções para eventos
function loadEventos() {
    getDB().then(db => {
        db.getAll('eventos').then(eventos => {
            const table = document.getElementById('eventos-table');
            table.innerHTML = '';
            
            if (eventos.length === 0) {
                table.innerHTML = '<tr><td colspan="6">Nenhum evento cadastrado</td></tr>';
                return;
            }
            
            // Ordena por data mais próxima
            eventos.sort((a, b) => new Date(a.data) - new Date(b.data));
            
            eventos.forEach(evento => {
                const data = new Date(evento.data);
                const hoje = new Date();
                const status = data < hoje ? 'Realizado' : 'Agendado';
                
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${evento.titulo}</td>
                    <td>${data.toLocaleDateString()}</td>
                    <td>${evento.hora}</td>
                    <td>${evento.local}</td>
                    <td>${evento.responsavel?.nome || '-'}</td>
                    <td>
                        <button class="btn btn-sm btn-outline-primary btn-action" data-id="${evento.id}" onclick="viewEvento('${evento.id}')">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="btn btn-sm btn-outline-danger btn-action" data-id="${evento.id}" onclick="deleteEvento('${evento.id}')">
                            <i class="fas fa-trash"></i>
                        </button>
                    </td>
                `;
                table.appendChild(row);
            });
        });
    });
}

function showAddEventoModal() {
    // Limpa o formulário
    document.getElementById('evento-form').reset();
    document.getElementById('musicas-evento').innerHTML = '';
    
    // Preenche a data padrão (amanhã)
    const amanha = new Date();
    amanha.setDate(amanha.getDate() + 1);
    document.getElementById('evento-data').valueAsDate = amanha;
    
    // Carrega os membros para o dropdown de responsável
    getDB().then(db => {
        db.getAll('membros').then(membros => {
            const select = document.getElementById('evento-responsavel');
            select.innerHTML = '<option value="">Selecione...</option>';
            
            membros.forEach(membro => {
                const option = document.createElement('option');
                option.value = membro.id;
                option.textContent = membro.nome;
                select.appendChild(option);
            });
        });
        
        // Carrega as músicas para o dropdown
        db.getAll('musicas').then(musicas => {
            const select = document.getElementById('select-musica-evento');
            select.innerHTML = '<option selected>Selecione uma música...</option>';
            
            musicas.forEach(musica => {
                const option = document.createElement('option');
                option.value = musica.id;
                option.textContent = musica.titulo;
                select.appendChild(option);
            });
        });
    });
    
    // Mostra o modal
    const modal = new bootstrap.Modal(document.getElementById('addEventoModal'));
    modal.show();
}

function addMusicaToEvento() {
    const select = document.getElementById('select-musica-evento');
    const musicaId = select.value;
    
    if (!musicaId || musicaId === 'Selecione uma música...') {
        showToast('Selecione uma música válida', 'warning');
        return;
    }
    
    getDB().then(db => {
        db.get('musicas', musicaId).then(musica => {
            const lista = document.getElementById('musicas-evento');
            
            // Verifica se a música já foi adicionada
            if (document.querySelector(`#musicas-evento li[data-id="${musica.id}"]`)) {
                showToast('Esta música já foi adicionada', 'warning');
                return;
            }
            
            const item = document.createElement('li');
            item.className = 'list-group-item d-flex justify-content-between align-items-center';
            item.dataset.id = musica.id;
            item.innerHTML = `
                ${musica.titulo} (${musica.tonalidade || 'N/D'})
                <button class="btn btn-sm btn-outline-danger" onclick="this.parentElement.remove()">
                    <i class="fas fa-times"></i>
                </button>
            `;
            
            lista.appendChild(item);
            select.value = 'Selecione uma música...';
        });
    });
}

function saveEvento() {
    const titulo = document.getElementById('evento-titulo').value;
    const data = document.getElementById('evento-data').value;
    const hora = document.getElementById('evento-hora').value;
    const local = document.getElementById('evento-local').value;
    const descricao = document.getElementById('evento-descricao').value;
    const responsavelId = document.getElementById('evento-responsavel').value;
    const passagemData = document.getElementById('evento-passagem-data').value;
    const passagemHora = document.getElementById('evento-passagem-hora').value;
    
    if (!titulo || !data || !hora || !local) {
        showToast('Preencha todos os campos obrigatórios', 'warning');
        return;
    }
    
    // Coleta as músicas selecionadas
    const musicas = [];
    document.querySelectorAll('#musicas-evento li').forEach(li => {
        musicas.push(li.dataset.id);
    });
    
    // Obtém os detalhes do responsável
    getDB().then(db => {
        let responsavel = null;
        
        if (responsavelId) {
            db.get('membros', responsavelId).then(membro => {
                responsavel = membro;
                
                // Obtém os detalhes completos das músicas
                db.getAll('musicas').then(todasMusicas => {
                    const musicasCompletas = musicas.map(id => {
                        return todasMusicas.find(m => m.id === id);
                    });
                    
                    const evento = {
                        titulo,
                        data,
                        hora,
                        local,
                        descricao,
                        responsavel,
                        passagemSom: passagemData && passagemHora ? `${passagemData}T${passagemHora}` : null,
                        musicas: musicasCompletas,
                        createdAt: new Date().toISOString(),
                        updatedAt: new Date().toISOString()
                    };
                    
                    // Salva no banco de dados
                    db.add('eventos', evento).then(() => {
                        showToast('Evento salvo com sucesso!', 'success');
                        loadEventos();
                        loadDashboardData();
                        bootstrap.Modal.getInstance(document.getElementById('addEventoModal')).hide();
                    });
                });
            });
        } else {
            // Obtém os detalhes completos das músicas
            db.getAll('musicas').then(todasMusicas => {
                const musicasCompletas = musicas.map(id => {
                    return todasMusicas.find(m => m.id === id);
                });
                
                const evento = {
                    titulo,
                    data,
                    hora,
                    local,
                    descricao,
                    responsavel: null,
                    passagemSom: passagemData && passagemHora ? `${passagemData}T${passagemHora}` : null,
                    musicas: musicasCompletas,
                    createdAt: new Date().toISOString(),
                    updatedAt: new Date().toISOString()
                };
                
                // Salva no banco de dados
                db.add('eventos', evento).then(() => {
                    showToast('Evento salvo com sucesso!', 'success');
                    loadEventos();
                    loadDashboardData();
                    bootstrap.Modal.getInstance(document.getElementById('addEventoModal')).hide();
                });
            });
        }
    });
}

function viewEvento(id) {
    // Implementação para visualizar detalhes do evento
    console.log('Visualizar evento:', id);
}

function deleteEvento(id) {
    if (confirm('Tem certeza que deseja excluir este evento?')) {
        getDB().then(db => {
            db.delete('eventos', id).then(() => {
                showToast('Evento excluído com sucesso!', 'success');
                loadEventos();
                loadDashboardData();
            });
        });
    }
}

// Funções para membros
function loadMembros() {
    getDB().then(db => {
        db.getAll('membros').then(membros => {
            const table = document.getElementById('membros-table');
            table.innerHTML = '';
            
            if (membros.length === 0) {
                table.innerHTML = '<tr><td colspan="6">Nenhum membro cadastrado</td></tr>';
                return;
            }
            
            membros.forEach(membro => {
                const aniversario = membro.aniversario ? 
                    new Date(membro.aniversario).toLocaleDateString() : 
                    'N/D';
                
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${membro.nome}</td>
                    <td><span class="badge ${getFuncaoBadgeClass(membro.funcao)}">${membro.funcao}</span></td>
                    <td>${membro.telefone || 'N/D'}</td>
                    <td>${membro.email || 'N/D'}</td>
                    <td>${aniversario}</td>
                    <td>
                        <button class="btn btn-sm btn-outline-primary btn-action" data-id="${membro.id}" onclick="editMembro('${membro.id}')">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn btn-sm btn-outline-danger btn-action" data-id="${membro.id}" onclick="deleteMembro('${membro.id}')">
                            <i class="fas fa-trash"></i>
                        </button>
                    </td>
                `;
                table.appendChild(row);
            });
        });
    });
}

function showAddMembroModal() {
    // Limpa o formulário
    document.getElementById('membro-form').reset();
    document.getElementById('outra-funcao-container').style.display = 'none';
    delete document.getElementById('membro-form').dataset.id;
    
    // Mostra o modal
    const modal = new bootstrap.Modal(document.getElementById('addMembroModal'));
    modal.show();
}

function saveMembro() {
    const nome = document.getElementById('membro-nome').value;
    const telefone = document.getElementById('membro-telefone').value;
    const email = document.getElementById('membro-email').value;
    const funcao = document.getElementById('membro-funcao').value;
    const outraFuncao = document.getElementById('membro-outra-funcao').value;
    const aniversario = document.getElementById('membro-aniversario').value;
    const observacoes = document.getElementById('membro-observacoes').value;
    
    if (!nome || !funcao) {
        showToast('Preencha todos os campos obrigatórios', 'warning');
        return;
    }
    
    const membro = {
        nome,
        telefone,
        email,
        funcao: funcao === 'Outro' ? outraFuncao : funcao,
        aniversario,
        observacoes,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
    };
    
    const membroId = document.getElementById('membro-form').dataset.id;
    
    getDB().then(db => {
        if (membroId) {
            // Atualizar membro existente
            membro.id = membroId;
            db.update('membros', membro).then(() => {
                showToast('Membro atualizado com sucesso!', 'success');
                loadMembros();
                loadDashboardData();
                bootstrap.Modal.getInstance(document.getElementById('addMembroModal')).hide();
            });
        } else {
            // Adicionar novo membro
            db.add('membros', membro).then(() => {
                showToast('Membro adicionado com sucesso!', 'success');
                loadMembros();
                loadDashboardData();
                bootstrap.Modal.getInstance(document.getElementById('addMembroModal')).hide();
            });
        }
    });
}

function editMembro(id) {
    getDB().then(db => {
        db.get('membros', id).then(membro => {
            // Preenche o formulário
            document.getElementById('membro-nome').value = membro.nome;
            document.getElementById('membro-telefone').value = membro.telefone || '';
            document.getElementById('membro-email').value = membro.email || '';
            
            // Verifica se a função está na lista ou é "Outro"
            const funcaoSelect = document.getElementById('membro-funcao');
            const funcoesPadrao = Array.from(funcaoSelect.options).map(o => o.value);
            
            if (funcoesPadrao.includes(membro.funcao)) {
                funcaoSelect.value = membro.funcao;
                document.getElementById('outra-funcao-container').style.display = 'none';
            } else {
                funcaoSelect.value = 'Outro';
                document.getElementById('outra-funcao-container').style.display = 'block';
                document.getElementById('membro-outra-funcao').value = membro.funcao;
            }
            
            document.getElementById('membro-aniversario').value = membro.aniversario || '';
            document.getElementById('membro-observacoes').value = membro.observacoes || '';
            
            // Armazena o ID para atualização
            document.getElementById('membro-form').dataset.id = membro.id;
            
            // Mostra o modal
            const modal = new bootstrap.Modal(document.getElementById('addMembroModal'));
            modal.show();
        });
    });
}

function deleteMembro(id) {
    if (confirm('Tem certeza que deseja excluir este membro?')) {
        getDB().then(db => {
            db.delete('membros', id).then(() => {
                showToast('Membro excluído com sucesso!', 'success');
                loadMembros();
                loadDashboardData();
            });
        });
    }
}

// Funções para mensagens
function loadMensagens() {
    // Carrega os membros para o dropdown de destinatários
    getDB().then(db => {
        db.getAll('membros').then(membros => {
            const select = document.getElementById('mensagem-destinatarios');
            select.innerHTML = '';
            
            membros.forEach(membro => {
                const option = document.createElement('option');
                option.value = membro.id;
                option.textContent = membro.nome;
                select.appendChild(option);
            });
        });
    });
}

function showAddMensagemModal() {
    // Limpa o formulário
    document.getElementById('mensagem-form').reset();
    
    // Mostra o modal
    const modal = new bootstrap.Modal(document.getElementById('addMensagemModal'));
    modal.show();
}

function updateMensagemModelo() {
    const modelo = document.getElementById('mensagem-modelo').value;
    let texto = '';
    
    switch(modelo) {
        case 'convite':
            texto = 'Olá {nome}, você está convidado(a) para o ensaio de louvor no dia {data} às {hora}. Local: {local}. Por favor, confirme sua presença.';
            break;
        case 'confirmacao':
            texto = 'Olá {nome}, confirmamos sua participação na escala de louvor do dia {data} às {hora}. Por favor, chegue com antecedência para o alinhamento.';
            break;
        case 'lembrete':
            texto = 'Olá {nome}, lembrete: evento de louvor amanhã às {hora}. Não se esqueça de levar seu {instrumento}.';
            break;
        case 'personalizada':
            texto = '';
            break;
    }
    
    document.getElementById('mensagem-texto').value = texto;
}

function testarMensagem() {
    const texto = document.getElementById('mensagem-texto').value;
    
    if (!texto) {
        showToast('Digite uma mensagem para testar', 'warning');
        return;
    }
    
    // Substitui placeholders por exemplos
    const mensagemTeste = texto
        .replace(/{nome}/g, 'João')
        .replace(/{data}/g, '15/08/2023')
        .replace(/{hora}/g, '19:30')
        .replace(/{local}/g, 'Igreja Central')
        .replace(/{instrumento}/g, 'violão');
    
    alert('Visualização da mensagem:\n\n' + mensagemTeste);
}

function enviarMensagem() {
    const modelo = document.getElementById('mensagem-modelo').value;
    const destinatarios = Array.from(document.getElementById('mensagem-destinatarios').selectedOptions)
                              .map(option => option.value);
    const texto = document.getElementById('mensagem-texto').value;
    const dataAgendamento = document.getElementById('mensagem-data').value;
    
    if (destinatarios.length === 0) {
        showToast('Selecione pelo menos um destinatário', 'warning');
        return;
    }
    
    if (!texto) {
        showToast('Digite a mensagem a ser enviada', 'warning');
        return;
    }
    
    // Obtém os detalhes dos destinatários
    getDB().then(db => {
        db.getAll('membros').then(membros => {
            const destinatariosCompletos = destinatarios.map(id => {
                return membros.find(m => m.id === id);
            });
            
            const mensagem = {
                modelo,
                destinatarios: destinatariosCompletos,
                texto,
                dataAgendamento,
                enviada: false,
                createdAt: new Date().toISOString()
            };
            
            // Salva a mensagem (aqui você implementaria o envio real pelo WhatsApp)
            db.add('mensagens', mensagem).then(() => {
                showToast('Mensagem preparada para envio!', 'success');
                
                // Aqui você implementaria a integração com a API do WhatsApp
                destinatariosCompletos.forEach(destinatario => {
                    const mensagemPersonalizada = personalizarMensagem(texto, destinatario);
                    console.log(`Enviando para ${destinatario.nome} (${destinatario.telefone}): ${mensagemPersonalizada}`);
                    
                    // Marca como enviada
                    mensagem.enviada = true;
                    mensagem.updatedAt = new Date().toISOString();
                    db.update('mensagens', mensagem);
                });
                
                loadMensagens();
            });
        });
    });
}

function personalizarMensagem(texto, membro) {
    const data = new Date();
    const hora = data.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    
    return texto
        .replace(/{nome}/g, membro.nome.split(' ')[0])
        .replace(/{data}/g, data.toLocaleDateString())
        .replace(/{hora}/g, hora)
        .replace(/{local}/g, 'Igreja')
        .replace(/{instrumento}/g, membro.funcao === 'Guitarrista' ? 'guitarra' : 
                                  membro.funcao === 'Violonista' ? 'violão' :
                                  membro.funcao === 'Baterista' ? 'baquetas' :
                                  membro.funcao === 'Tecladista' ? 'teclado' :
                                  'instrumento');
}

// Funções para configurações
function loadConfig() {
    getDB().then(db => {
        db.get('config', 'geral').then(config => {
            if (config) {
                document.getElementById('config-nome-grupo').value = config.nomeGrupo || '';
                document.getElementById('config-igreja').value = config.igreja || '';
                document.getElementById('config-responsavel').value = config.responsavel || '';
                document.getElementById('config-email').value = config.email || '';
                document.getElementById('config-notificacoes').checked = config.notificacoes || false;
                document.getElementById('config-sincronizacao-auto').checked = config.sincronizacaoAuto || false;
            }
        });
        
        // Atualiza status da sincronização
        updateSyncStatus();
    });
}

function salvarConfigGeral() {
    const config = {
        id: 'geral',
        nomeGrupo: document.getElementById('config-nome-grupo').value,
        igreja: document.getElementById('config-igreja').value,
        responsavel: document.getElementById('config-responsavel').value,
        email: document.getElementById('config-email').value,
        notificacoes: document.getElementById('config-notificacoes').checked,
        sincronizacaoAuto: document.getElementById('config-sincronizacao-auto').checked,
        updatedAt: new Date().toISOString()
    };
    
    getDB().then(db => {
        db.put('config', config).then(() => {
            showToast('Configurações salvas com sucesso!', 'success');
        });
    });
}

function criarBackup() {
    getDB().then(db => {
        db.export().then(data => {
            const blob = new Blob([JSON.stringify(data)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            
            const a = document.createElement('a');
            a.href = url;
            a.download = `backup-louvormaster-${new Date().toISOString().split('T')[0]}.json`;
            a.click();
            
            URL.revokeObjectURL(url);
            
            showToast('Backup criado com sucesso!', 'success');
        });
    });
}

function restaurarBackup() {
    const fileInput = document.getElementById('restore-file');
    
    if (!fileInput.files.length) {
        showToast('Selecione um arquivo de backup', 'warning');
        return;
    }
    
    const file = fileInput.files[0];
    const reader = new FileReader();
    
    reader.onload = function(e) {
        try {
            const data = JSON.parse(e.target.result);
            
            if (confirm('Tem certeza que deseja restaurar este backup? Todos os dados atuais serão substituídos.')) {
                getDB().then(db => {
                    db.import(data).then(() => {
                        showToast('Backup restaurado com sucesso!', 'success');
                        location.reload();
                    }).catch(err => {
                        showToast('Erro ao restaurar backup: ' + err.message, 'danger');
                    });
                });
            }
        } catch (err) {
            showToast('Arquivo de backup inválido', 'danger');
        }
    };
    
    reader.readAsText(file);
}

function limparDadosLocais() {
    if (confirm('Tem certeza que deseja limpar TODOS os dados locais? Esta ação não pode ser desfeita.')) {
        indexedDB.deleteDatabase('LouvorMasterDB');
        localStorage.clear();
        showToast('Todos os dados locais foram removidos', 'success');
        setTimeout(() => location.reload(), 1500);
    }
}

// Funções de sincronização
function checkOnlineStatus() {
    const statusElement = document.getElementById('connection-status');
    
    function updateStatus() {
        if (navigator.onLine) {
            statusElement.textContent = 'Online';
            statusElement.classList.remove('bg-secondary');
            statusElement.classList.add('bg-success', 'online');
            
            // Verifica atualizações quando voltar a ficar online
            checkForUpdates();
        } else {
            statusElement.textContent = 'Offline';
            statusElement.classList.remove('bg-success', 'online');
            statusElement.classList.add('bg-secondary', 'offline');
        }
    }
    
    // Atualiza o status inicial
    updateStatus();
    
    // Monitora mudanças na conexão
    window.addEventListener('online', updateStatus);
    window.addEventListener('offline', updateStatus);
}

function checkForUpdates() {
    if (!navigator.onLine) return;
    
    getDB().then(db => {
        db.get('config', 'sync').then(syncConfig => {
            const lastSync = syncConfig?.lastSync || 0;
            
            // Aqui você implementaria a verificação de atualizações no servidor
            // Por enquanto, apenas simula
            console.log('Verificando atualizações desde', new Date(lastSync));
            
            // Atualiza o timestamp da última verificação
            db.put('config', { id: 'sync', lastSync: Date.now() });
        });
    });
}

function syncData() {
    if (!navigator.onLine) {
        showToast('Você está offline. Conecte-se para sincronizar.', 'warning');
        return;
    }
    
    showToast('Sincronizando dados...', 'info');
    
    // Aqui você implementaria a sincronização com o servidor
    // Por enquanto, apenas simula
    setTimeout(() => {
        showToast('Dados sincronizados com sucesso!', 'success');
        updateSyncStatus();
    }, 2000);
}

function updateSyncStatus() {
    getDB().then(db => {
        db.get('config', 'sync').then(syncConfig => {
            const statusElement = document.getElementById('sync-status');
            
            if (syncConfig?.lastSync) {
                statusElement.innerHTML = `
                    Última sincronização: <strong>${new Date(syncConfig.lastSync).toLocaleString()}</strong>
                `;
                statusElement.className = 'alert alert-success';
            } else {
                statusElement.textContent = 'Nunca sincronizado';
                statusElement.className = 'alert alert-warning';
            }
        });
    });
}

// Utilitários
function showToast(message, type = 'info') {
    const toastContainer = document.createElement('div');
    toastContainer.className = `toast align-items-center text-white bg-${type} border-0`;
    toastContainer.setAttribute('role', 'alert');
    toastContainer.setAttribute('aria-live', 'assertive');
    toastContainer.setAttribute('aria-atomic', 'true');
    
    toastContainer.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">
                ${message}
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
    `;
    
    document.body.appendChild(toastContainer);
    
    const toast = new bootstrap.Toast(toastContainer, {
        autohide: true,
        delay: 3000
    });
    
    toast.show();
    
    toastContainer.addEventListener('hidden.bs.toast', function() {
        document.body.removeChild(toastContainer);
    });
}

// Inicializa o Service Worker para PWA
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('sw.js').then(registration => {
            console.log('ServiceWorker registration successful');
        }).catch(err => {
            console.log('ServiceWorker registration failed: ', err);
        });
    });
}